from django.apps import AppConfig


class DjangoInterfaceConfig(AppConfig):
    name = 'django_interface'
