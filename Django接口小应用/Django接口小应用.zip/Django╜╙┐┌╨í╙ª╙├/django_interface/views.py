from django.shortcuts import render, HttpResponse
from .forms import DateForm
from user.models import Token
import json
import jwt

# Create your views here.
def index(request):
    """主页"""
    if request.method != 'POST':
        form = DateForm()
        text = ""
    else:
        form = DateForm(request.POST)
        text = ""
        token_login = jwt.encode({"username": request.user.username}, "secret_key", algorithm='HS256')
        if (Token.objects.filter(token = token_login).exists()):
            if form.is_valid():
                text = form.cleaned_data['Date']
                text = text.split('-')
                if (text[1] == '01' and text[2] == '01'):
                    text = "元旦"
                elif (text[1] == '12' and text[2] == '25'):
                    text = "圣诞节"
                elif (text[1] == '10' and text[2] == '01'):
                    text = "国庆节"
                else:
                    text = ""
                text = {"Festival": text}
                return HttpResponse(json.dumps(text, ensure_ascii=False), content_type='application/json', charset='utf-8')
        else:
            return HttpResponse(json.dumps("No login!"))
    return render(request, 'django_interface/index.html', {'form': form})