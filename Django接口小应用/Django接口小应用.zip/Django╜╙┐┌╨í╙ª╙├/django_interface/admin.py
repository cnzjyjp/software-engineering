from django.contrib import admin

from django_interface.models import DateQuery

admin.site.register(DateQuery)
