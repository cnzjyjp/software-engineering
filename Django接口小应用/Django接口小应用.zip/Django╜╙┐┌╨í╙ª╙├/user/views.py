from django.shortcuts import render, HttpResponse
from .models import Token
from django.contrib.auth.forms import UserCreationForm
import json
import jwt

def index(request):
    token = jwt.encode({"username": request.user.username}, "secret_key", algorithm='HS256')
    token_model = Token()
    token_model.token = token
    token_model.save()
    token = {"token": token.decode()}
    return HttpResponse(json.dumps(token))


def signup(request):
    """注册新用户"""
    if request.method != 'POST':
        # 显示空的注册表单
        form = UserCreationForm
    else:
        # 处理填写好的表单
        form = UserCreationForm(data=request.POST)

        if form.is_valid():
            new_user = form.save()
            return HttpResponse(json.dumps({"status": "signup successfully"}))
        else:
            return HttpResponse(json.dumps({"status": "signup unsuccessfully"}))

    context = {'form': form}
    return render(request, 'user/signup.html', context)       