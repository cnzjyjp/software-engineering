from django.contrib import admin
from .models import LessonInfo, UserInfo, Question, Answers, UserInLesson
# Register your models here.

admin.site.register(LessonInfo)
admin.site.register(UserInfo)
admin.site.register(UserInLesson)
admin.site.register(Question)
admin.site.register(Answers)
