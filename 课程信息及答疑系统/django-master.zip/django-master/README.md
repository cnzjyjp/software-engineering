﻿# 软工项目-2020

## 课程信息及答疑系统
本项目前端基于Vue.js，后端基于Django，分别完成网站页面和数据库，并实现网页和数据库的交互

**注意**：请将Vue项目和Django的app放在同一级目录

## v2.0使用方法

### 后端

详见下方后端配置说明

另：

```shell
pip install django-cors-headers django-cookies-samesite
```

### 前端

在frontend目录下

```shell
npm install
npm start
```

### 后端接口说明

见同目录的**接口说明.md**

- 以上接口的返回数据具体参见`./backend/models.py`
### 使用方式

- vue的配置

  - 目录结构如下

  ```
  `
  +-- webapp
  +-- backend
  +-- frontend
  ```

  - 打包vue目录，打包完后会生成dist文件夹，内有index.html

- 配置数据库

  - 修改webapp/setting.py

  ```python
  DATABASES = {
      'default': {
          'ENGINE': 'django.db.backends.mysql',
          'USER':'root',#你自己数据库的user名
          'PASSWORD':'eric0510',#自己数据库的密码
          'NAME':'test',#首先需要新建一个database
          'HOST':'127.0.0.1',
          'PORT':3306,
      }
  }
  ```

  - 迁移到数据库：

    在根目录下输入以下指令

  ```bash
  python manage.py makemigrations
  python manage.py migrate
  ```

  新建一个超级用户

  `python manage.py createsuperuser`

  ##### 启动项目

  在根目录输入以下指令：

  ```bash
  python manage.py runserver
  ```

  ##### 至此前端可以正常与后端进行数据交互

- 添加数据

  方法一（推荐）

  使用超级用户登录http://127.0.0.1:8000/admin

  在控制台进行数据的增添修改

  方法二

  利用manage.py提供的shell进行添加数据的操作，在根目录下输入以下指令进入shell

  ```bash
  python manage.py shell
  ```

  - 用户数据

  ```python
  from backend.models import UserInfo
  user = UserInfo.objects.create_user(username = 'xxx',password = 'xxx',realname = 'xxx',type = 'xxx')
  user.save()
  ```

  - 其他数据（涉及外键模型的数据添加比较繁琐，故暂时只给出一般的模型，以课程信息为例）

  ```python
  from backend.models import LessonInfo
  lesson = LessonInfo(lesson_id = x,name = 'xxx',notice = 'xx',term = 'xx')
  lesson.save()
  ```

  
