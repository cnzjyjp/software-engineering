from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone

# Create your models here.

class LessonInfo(models.Model):
    lesson_id = models.IntegerField()
    name = models.CharField(max_length = 40)
    notice = models.CharField(max_length = 256)
    term = models.IntegerField()
    class Meta:
        unique_together = ("lesson_id","term")

    def __str__(self):
        return self.name
   
class UserInfo(AbstractUser):
    realname = models.CharField(max_length = 30)
    type = models.CharField(max_length = 10)

    def __str__(self):
        return self.realname + self.type

class UserInLesson(models.Model):
    user_id = models.ForeignKey(UserInfo,on_delete=models.CASCADE,to_field='id')
    lesson_id = models.ForeignKey(LessonInfo,on_delete=models.CASCADE,to_field='id')

class Question(models.Model):
    question_id = models.AutoField(primary_key = True)
    lesson_id = models.ForeignKey(LessonInfo, on_delete=models.CASCADE,to_field='id')
    title = models.CharField(max_length = 40)
    description = models.CharField(max_length = 256)
    answer_teacher = models.CharField(max_length = 1024,default='no answer')
    answer_student = models.CharField(max_length = 1024,default='no answer')
    published_date = models.DateTimeField()
    problem_solved = models.BooleanField()

    def __str__(self):
        return self.title

class Answers(models.Model):
    id = models.AutoField(primary_key = True)
    question_id = models.ForeignKey(Question, on_delete = models.CASCADE,to_field='question_id')
    student_id = models.ForeignKey(UserInfo, on_delete = models.CASCADE, to_field='id')
    context = models.CharField(max_length = 1024)

class Files(models.Model):
    lesson_id = models.ForeignKey(LessonInfo, on_delete=models.CASCADE,to_field='id')
    file_name = models.CharField(max_length=500)
    file_size = models.DecimalField(max_digits=10, decimal_places=0)
    upload_time = models.DateTimeField(default=timezone.now())
    