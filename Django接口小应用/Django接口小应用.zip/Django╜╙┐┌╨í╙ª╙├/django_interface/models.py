from django.db import models

class DateQuery(models.Model):
    """日期"""
    Date = models.CharField(max_length=10)

    def __str__(self):
        return self.Date