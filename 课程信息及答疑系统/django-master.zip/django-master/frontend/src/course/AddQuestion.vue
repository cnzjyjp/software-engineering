<template>
  <div>
    <form ref="form" :model="form" label-width="120px">
      <form label="Question Title">
        <input type="textarea" placeholder="标题" class="q_desc" v-model="form.title" />
      </form>

      <form label="Question Description">
        <input type="textarea"  placeholder="详细描述问题"  v-model="form.desc"  class="q_desc"/>
      </form>
      <form>
        <button type="primary" @click="onSubmit">Create</button>
        <button @click="onCancel">Cancel</button>
      </form>
    </form>
  </div>
  
</template>

<script>
import axios from 'axios';
axios.defaults.withCredentials = true
import config from 'config';
export default {
  data() {
    return {
      form: {
        title: '',
        desc: ''
      },
      message:''
    }
  },

methods: {
    onSubmit() {  
      let temp='lesson_id='+this.$route.params.course_id;
      temp=temp+'&'+'term='+this.$route.params.term;
      temp=temp+'&'+'title='+this.form.title;
      temp=temp+'&'+'description='+this.form.desc;
      axios.post(`${config.apiUrl}/lesson/question/add`, temp,
      {
          withCredentials: true,
          headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
          },
      }      
      ).then(response=>{
        if(response.data.status == 0){
            this.$message('问题已经成功提交');
        }
        else{
          this.$message('问题提交失败');
          // location.reload(true);
        }
      }).catch(error=>{this.$message('问题提交失败')});
      
      this.$router.push({name:'qazone',params:{term:this.$route.params.term,course_id:this.$route.params.course_id}});//该课程答疑区
    },
    onCancel() {
      this.$router.push({name:'qazone',params:{term:this.$route.params.term,course_id:this.$route.params.course_id}})//该课程答疑区
    }
  }
}
</script>
<style scoped>

.q_desc {
    display: block;
    resize: vertical;
    padding: 5px 15px;
    line-height: 1.5;

    box-sizing: border-box;
    width: 100%;
    font-size: inherit;
    color: #606266;
    background-color: #FFF;
    background-image: none;
    border: 1px solid #DCDFE6;
    border-radius: 4px;

}
</style>
