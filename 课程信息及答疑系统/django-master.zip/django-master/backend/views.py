from django.shortcuts import render
from django.http import JsonResponse,FileResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from .models import *
import json
import os
import time

# Create your views here.


def login_user(request):
    print(request.COOKIES)
    if request.method == 'POST':
        print("zzzz1")
        print(request)
        print(request.POST)
        print(request.body)
        username = request.POST.get("username",'')
        password = request.POST.get("password",'')
        if username is not None and password is not None:
            islogin = authenticate(request, username=username, password=password)
            if islogin:
                login(request, islogin)
                user = UserInfo.objects.get(username = username)
                return JsonResponse({
                    "status": 0,
                    "message": "Login Success",
                    "usertype": user.type,
                    "username": user.username
                })
            else:
                return JsonResponse({
                    "status": 1,
                    "message": "Login Failure"
            })
        else:
            return JsonResponse({
                "status": 2,
                "message": "Invalid Parameters"
            })


def logout_user(request):
    logout(request)
    return JsonResponse({
        "status": 1
    })

def register_user(request):
    if request.method == 'POST':
        print(request)
        print(request.POST)
        username = request.POST.get("username")
        password = request.POST.get("password")
        realname = request.POST.get("realname")
        usertype = request.POST.get("usertype")
        if username is not None and password is not None and realname is not None and usertype is not None:
            try:
                user = UserInfo.objects.create_user(username=username,password=password,realname=realname,type = usertype)
                user.save()
                return JsonResponse({
                    "status": 0,
                    "message": "succussfully registered"
                })
            except:
                return JsonResponse({
                    "status": 3,
                    "message": "user exits,register fail"
                })
        else:
            return JsonResponse({
                "status": 2,
                "message": "Invalid input"
            })    

@login_required
def get_lessoninfo(request):
    print(3)
    print(request)
    print(4)
    print(request.COOKIES)
    print(5)
    if request.method == 'POST':
        lesson_id = request.POST.get("lesson_id")
        term = request.POST.get("term")
        if lesson_id is not None and term is not None:
            item_lesson = LessonInfo.objects.filter(lesson_id=int(lesson_id),term = int(term))
            if item_lesson:
                item_lesson = LessonInfo.objects.get(lesson_id=int(lesson_id),term = int(term))
                lesson_info = {
                    "lesson_id": item_lesson.lesson_id,
                    "name": item_lesson.name,
                    "notice": item_lesson.notice,
                    "term": item_lesson.term
                }
            else:
                lesson_info = 'None'
            return JsonResponse({
                "lesson_info": lesson_info
            })
        else:
            return JsonResponse({
                "status": 2,
                "message": "Invalid input"
            })
            
@login_required
def get_lessonterms(request):
    if request.method == 'POST':
        lesson_id = request.POST.get("lesson_id")
        if lesson_id is not None:
            item_lesson =  LessonInfo.objects.filter(lesson_id=int(lesson_id))
            if item_lesson:
                terms = [{
                    "term":i.term
                }
                for i in item_lesson]
            else:
                terms = 'None'
            return JsonResponse({
                "term_info":terms
            })
        else:
            return JsonResponse({
                "status": 2,
                "message": "Invalid input"
            })

@login_required
def get_questioninfo(request):
    if request.method == 'POST':
        lesson_id = request.POST.get("lesson_id")
        term = request.POST.get("term")
        if lesson_id is not None and term is not None:
            lesson = LessonInfo.objects.get(lesson_id = lesson_id,term = term)
            item_question = Question.objects.filter(lesson_id=lesson)
            if item_question:
                question_info = [{
                    "question_id": i.question_id,
                    "title": i.title,
                    "description":i.description,
                    "answer_teacher": i.answer_teacher,
                    "answer_student": i.answer_student,
                    "published_date": i.published_date,
                    "problem_solved": i.problem_solved
                }
                for i in item_question]
            else:
                question_info = 'None'
            return JsonResponse({
                "question_info":question_info
            })
        else:
            return JsonResponse({
                "status": 2,
                "message": "Invalid input"
            })

@login_required
def get_answers(request):
    if request.method == 'POST':
        question_id = request.POST.get("question_id")
        if question_id is not None:
            detail = Answers.objects.filter(question_id = question_id)
            data = [
                {
                    "answer_id": i.id,
                    "student_name": UserInfo.objects.get(id=i.student_id).realname,
                    "context":i.context
                }
            for i in detail]
            return JsonResponse({
                "answers":data
            })

@login_required
def get_user_lessons(request):
    if request.method == 'POST':
        term = request.POST.get("term")
        username = request.POST.get("username")
        if term is not None and username is not None:
            user_id = UserInfo.objects.get(username=username)
            lessons = UserInLesson.objects.filter(user_id=user_id)
            user_lessons = [
                {
                    "lesson_id": LessonInfo.objects.get(id=i.lesson_id.id).lesson_id,
                    "lesson_name":LessonInfo.objects.get(id=i.lesson_id.id).name,
                    "lesson_term": LessonInfo.objects.get(id=i.lesson_id.id).term             
                }
            for i in lessons]
            return_lessons = []
            if int(term) != -1:
                for i in range(0, len(user_lessons)):
                    if user_lessons[i]["lesson_term"] == int(term):
                        return_lessons.append(user_lessons[i])
            else:
                term_values = [i.lesson_term for i in lessons]
                max_term = max(term_values)
                for i in range(0, len(user_lessons)):
                    if user_lessons[i]["lesson_term"] == max_term:
                        return_lessons.append(user_lessons[i])
            return JsonResponse({
                "user_lessons": return_lessons
            })

@login_required
def create_question(request):
    if request.method == 'POST':
        lesson_id = request.POST.get("lesson_id")
        term = request.POST.get("term")
        title = request.POST.get("title")
        description = request.POST.get("description")
        if lesson_id is not None and term is not None and title is not None and description is not None:
            lesson = LessonInfo.objects.get(lesson_id = lesson_id,term = term)
            question = Question(lesson_id = lesson,title = title,description = description,published_date=timezone.now(),problem_solved = 0)
            question.save()
            return JsonResponse({
                "status":0,
                "message":"succussfully created"
            })
        else:
            return JsonResponse({
                "status":2,
                "message":"Invalid input"
            })

@login_required
def answer_question(request):
    if request.method == 'POST': 
        question_id = request.POST.get("question_id")
        username = request.POST.get('username')
        answer = request.POST.get('answer')
        if question_id is not None and username is not None and answer is not None:
            question = Question.objects.get(question_id = question_id)
            usertype = UserInfo.objects.get(username = username).type
            if usertype == 'teacher':
                question.answer_teacher = answer
                question.problem_solved = 1
                question.save()
            else:
                question.answer_student = answer
                question.save()
                user = UserInfo.objects.get(username = username)
                ans = Answers(question_id = question,student_id = user,context = answer)
                ans.save()
            return JsonResponse({
                "status":0,
                "message":"succussfully answered"
            })
        else:
            return JsonResponse({
                "status":2,
                "message":"Invalid input"
            })

@login_required
def upload_file(request):
    if request.method == 'POST':
        lesson_id = request.POST.get('lesson_id')
        term = request.POST.get('term')
        files = request.FILE.getlist('files')
        if lesson_id is not None and term is not None:
            lesson = LessonInfo.objects.get(lesson_id = lesson_id, term = term)
            if not files:
                return JsonResponse({
                    "status":-1,
                    "message":"no files uploaded"
                })
            else:
                count = 0
                for f in files:
                    count = count + 1
                    path = os.path.join('D:\\files',lesson_id,term,f.name)
                    file_info = Files(lesson_id = lesson, file_name = f.name, file_size = 0 if 0<f.size<1024 else f.size/1024)
                    file_info.save()
                    des = open(path,'wb+')
                    for chunk in f.chunks():
                        des.write(chunk)
                    des.close()
                return JsonResponse({
                    "status":0,
                    "file_count":count,
                    "message":"succussfully uploaded"
                })
        else:
            return JsonResponse({
                "status":2,
                "message":"Invalid input"
            })

@login_required
def download_file(request):
    if request.method == 'POST':
        lesson_id = request.POST.get('lesson_id')
        term = request.POST.get('term')
        file_name = request.POST.get('file_name')
        if lesson_id is not None and term is not None and file_name is not None:
            path = os.path.join('D:\\files',lesson_id,term,file_name)
            file = open(path,'rb')
            return FileResponse(file)
        else:
            return JsonResponse({
                "status":2,
                "message":"Invalid input"
            })

@login_required
def file_list(request):
    if request.method == 'POST':
        lesson_id = request.POST.get('lesson_id')
        term = request.POST.get('term')
        if lesson_id is not None and term is not None:
            lesson = LessonInfo.objects.get(lesson_id = lesson_id, term = term)
            files = Files.objects.filter(lesson_id = lesson)
            if files:
                file_info =  [{
                    'file_name':i.file_name,
                    'file_size':i.file_size,
                    'upload_time':i.upload_time
                }
                for i in files]
            else:
                file_info = 'None'
            return JsonResponse({
                "file_info":file_info
            })
        else:
            return JsonResponse({
                "status": 2,
                "message": "Invalid input"
            })
