import Vue from 'vue';
import VeeValidate from 'vee-validate';

import { store } from './_store';
import { router } from './_helpers';
import ElementUI, { Form } from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import App from './app/App';
import axios from 'axios'
import Vueaxios from 'vue-axios'
axios.defaults.withCredentials=true;
//Vue.use(VueAxios,axios);
//Vue.prototype.$test = axios
Vue.use(VeeValidate);
Vue.use(ElementUI);
// setup fake backend
// import { configureFakeBackend } from './_helpers';
// configureFakeBackend();
//Vue.component(Button.name, Button);
//Vue.component(Select.name, Select);
//Vue.use(Form);
new Vue({
    el: '#app',
    router,
    store,
    render: h => h(App)
});