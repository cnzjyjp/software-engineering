<template>
<div>
  <el-select v-model="term" size:medium  placeholder="请选择" class="select_term" @change="changeTerm($event)">
    <el-option
      v-for="item in options"
      :key="item.value"
      :label="item.label"
      :value="item.value">
    </el-option>
  </el-select>
        <p v-if="course_list.length === 0">No Lessons</p>
        <div class="msg" v-for="(course, index) in course_list" :key="index">
            <router-link :to="'/courses/'+course.lesson_term+'/'+course.lesson_id">{{course.lesson_name}}</router-link>
        </div>
        <p>
            <router-link to="/home">返回主页</router-link>
        </p>

    </div>
</template>

<script>
import axios from 'axios';
axios.defaults.withCredentials = true
import config from 'config';
export default {
    data () {
        return {
            course_id: '1',
            options: [{
                value: '201',
                label: '2020春季学期'
                }, {
                value: '192',
                label: '2019秋季学期'
                }, {
                value: '191',
                label: '2019春季学期'
                }, {
                value: '182',
                label: '2018秋季学期'
                }, {
                value: '181',
                label: '2018春季学期'
                }],
                term: '',
                course_list:''
            }
    },
    methods: {
        changeTerm(e){
            console.log(e);
            const user = localStorage.getItem('user');
            console.log(user);
            const userObj = JSON.parse(user)
            let temp='username='+userObj+'&'+'term='+this.term;
            axios.post(`${config.apiUrl}/user/lessons`, temp,
                {
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                })
                .then(this.handleCourseList)            
        },
        handleCourseList(response)
        {
            console.log(response);
            console.log(response.data.user_lessons);
            this.course_list=response.data.user_lessons;
        }
    }
}
</script>

<style>
 .select_term{
    width:400px;
    text-align:center;
  }  
</style>