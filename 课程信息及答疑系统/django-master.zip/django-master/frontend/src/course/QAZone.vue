<template>
    <div>
        <router-view></router-view>
        <p>
            <router-link :to="'/courses/'+$route.params.term+'/'+$route.params.course_id+'/qazone'+'/addquestion'">创建新问题</router-link>
        </p>
        <button @click="UpdateQuestion">更新</button>
        <p>
            <router-link :to="'/courses/'+$route.params.term+'/'+$route.params.course_id">返回课程信息</router-link>
        </p>
        <div v-if="questions==='None'">  <p> 当前没有问题</p></div>
        <div v-else class="msg" v-for="(question, index) in questions" :key="index">
            <p class="msg-index">[{{index}}]</p>
            <!-- <p class="msg-subject" v-html="question.question_id"></p> -->
            <p class="msg-body" > title :{{question.title}}</p>
            <p class="msg-body">description:{{question.description}}</p>
            <p class="msg-body" >teacher answer:{{question.answer_teacher}}</p>
            <p class="msg-body" >student answer:{{question.answer_student}}</p>
            <p class="msg-body" >published_date:{{question.published_date}}</p>
            <p class="msg-body" >solved? {{question.problem_solved}}</p>
            <input v-if="!question.problem_solved" type="submit" @click="showForm(index)" value="Add answer" />
            <div v-if="addAnswerShow===index">
                <form ref="form"  label-width="120px">
                <form label="Question Title">
                    <input type="textarea" placeholder="答案" class="q_desc" v-model="answer" />
                </form>
                <form>
                    <button type="primary" @click="onSubmit(question.question_id)">Add</button>
                    <button @click="onCancel">Cancel</button>
                </form>
                </form>                    
            </div>
            <!-- <router-link v-if="!question.problem_solved" :to="'/courses/'+$route.params.term+'/'+$route.params.course_id+'/qazone'+'/addanswer'">添加回答</router-link> -->
            <!-- <router-view  name="answer"></router-view> -->
        </div>
    </div>
</template>

<script>
import axios from 'axios';
axios.defaults.withCredentials = true
import config from 'config';
export default {
    data () {
        return {
            questions:'',
            addAnswerShow:-1,
            answer:'',
        }
    },
    created:function(){
        this.UpdateQuestion();
    },
    watch: {
        // 如果路由有变化，会再次执行该方法
        '$route': 'UpdateQuestion'
    },
    methods:{
        UpdateQuestion(){
            console.log('update');
            let temp='lesson_id='+this.$route.params.course_id+'&'+'term='+this.$route.params.term;
            axios.post(`${config.apiUrl}/lesson/question/info`, temp,
                {
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                })
                .then(this.handleQuestion)               
        },
        handleQuestion(response){
            console.log('11');
            console.log(response);
            console.log(response.data);
            this.questions=response.data.question_info;
            console.log(this.questions)
        },
        onSubmit(id) {  
            const user = localStorage.getItem('user');
            // console.log(user);
            const userObj = JSON.parse(user);
            let temp='username='+userObj+'&'+'question_id='+id+'&answer='+this.answer;
            axios.post(`${config.apiUrl}/lesson/question/answer`, temp,
            {
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            }      
            ).then(response=>{
                if(response.data.status == 0){
                    this.$message('answer已经成功提交');
                }
                else{
                this.$message('answer提交失败');
                // location.reload(true);
                }
            }).catch(error=>{this.$message('answer提交失败')});
            this.addAnswerShow=-1;
            this.UpdateQuestion();
        },
        onCancel() {
            this.addAnswerShow=-1;
        // this.$router.push({name:'qazone',params:{term:this.$route.params.term,course_id:this.$route.params.course_id}})//该课程答疑区
        },
        showForm(index){
            this.addAnswerShow=index;
        } 
    }
}
</script>

<style scoped>

.msg {
  margin: 0 auto;
  text-align: left;
  border-bottom: 1px solid #ccc;
  padding: 1rem;
}
.msg-body {
  color: rgb(15, 4, 4);
  font-size: 40px;
  /* margin-bottom: 0; */
}
.msg-index {
  color: #ccc;
  font-size: 0.8rem;
  /* margin-bottom: 0; */
}
.q_desc {
    display: block;
    resize: vertical;
    padding: 5px 15px;
    line-height: 1.5;

    box-sizing: border-box;
    width: 100%;
    font-size: inherit;
    color: #606266;
    background-color: #FFF;
    background-image: none;
    border: 1px solid #DCDFE6;
    border-radius: 4px;

}

</style>