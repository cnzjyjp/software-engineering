"""为应用程序user定义URL模式"""

from django.conf.urls import url
from django.contrib.auth.views import LoginView

from . import views

urlpatterns = [
    # 登录页面
    url(r'^login/$', LoginView.as_view(template_name='user/login.html'), name="login"),
    # 登录的json信息
    url(r'^login/json/', views.index, name='index'),
    # 注册页面
    url(r'^signup/$', views.signup, name='signup'),
]