import config from 'config';
import { authHeader } from '../_helpers';
import axios from 'axios'
import { join } from 'path';
export const userService = {
    login,
    logout,
    register
};

function login(username, password) {
    let temp='username='+username+'&'+'password='+password;
    return axios.post(`${config.apiUrl}/login`,temp,
    {
        withCredentials: true,
        headers:{ 'Content-Type': 'application/x-www-form-urlencoded'},
    }
    )
    .then(handleResponse)
    .then(user => {
        // login successful if there's a jwt token in the response
        console.log('11');
        console.log(user)
        if (user) {
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem('user', JSON.stringify(user));
        }
        return user;
    });        
}

function logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('user');
    const requestOptions = {
        method: 'POST',
        credentials: 'include',
        headers: {...authHeader(), 'Content-Type': 'application/json' },
        body: ''
    };
    return axios.post(`${config.apiUrl}/logout`,
    {
        withCredentials: true,
        headers:{ 'Content-Type': 'application/json'},
    }).then(handleResponse);
}

function register(user) {
    let temp='username='+user.username+'&'+'password='+user.password+'&realname='+user.realname+'&usertype='+user.identity;
    return axios.post(`${config.apiUrl}/register`,temp,
    {
        withCredentials: true,
        headers:{ 'Content-Type': 'application/x-www-form-urlencoded'},
    })
    .then(handleResponse2);
}



function handleResponse(response) {
    console.log(response);
    console.log(response.body)
    console.log(response.data);
    // text=JSON.parse(response.data);
    if (response.statusText!="OK") {
        console.log(response.statusText);
        if (response.status === 401) {
            // auto logout if 401 response returned from api
            logout();
            location.reload(true);
        }
        const error = (response.data && response.data.message) || response.statusText;
        return Promise.reject(error);
    }
    else
    {
        console.log('17')
        console.log(response.data.status);
        if(response.data.status ==0)
        {
            return Promise.resolve(response.data.username)
        }
        else
        {
            console.log(6)
            return Promise.reject(response.data.message);
        }
    }
}

function handleResponse2(response) {
    console.log(response);
    console.log(response.body)
    console.log(response.data);
    // text=JSON.parse(response.data);
    if (response.statusText!="OK") {
        console.log(response.statusText);
        if (response.status === 401) {
            // auto logout if 401 response returned from api
            logout();
            location.reload(true);
        }
        const error = (response.data && response.data.message) || response.statusText;
        return Promise.reject(error);
    }
    else
    {
        console.log('17')
        console.log(response.data.status);
        if(response.data.status ==0)
        {
            return Promise.resolve(response.data.username)
        }
        else
        {
            console.log(6)
            return Promise.reject(response.data.message);
        }
    }
}