﻿<template>
  <div id="app">
    <div id="Rectangle1"></div>
    <div id="Rectangle2"></div>
    <div id="Header">
      <data-input v-bind:begin="begin" @CHour="hourlabel" @CMin="minlabel"
      @CSec="seclabel"></data-input>
      <buttons-display v-bind:begin="begin" v-bind:Inc="Inc" v-bind:Dec="Dec"
      v-bind:Clear="Clear" v-bind:Restart="Restart" v-bind:end="end" v-bind:paused="paused"
      v-bind:up="up" v-bind:down="down" @Pausing="Update" @Resuming="Update"></buttons-display>
      <hint-display v-bind:begin="begin" v-bind:hint="hint"></hint-display>
    </div>
    <number-display v-bind:msg="msg"></number-display>
  </div>
</template>

<script>
import ButtonsDisplay from './components/ButtonsDisplay'
import DataInput from './components/DataInput'
import HintDisplay from './components/HintDisplay'
import NumberDisplay from './components/NumberDisplay'
export default {
  name: 'App',
  components: {
    ButtonsDisplay,
    DataInput,
    HintDisplay,
    NumberDisplay
  },
  data: function () {
    return {
      begin: true,
      end: false,
      paused: false,
      up: false,
      down: false,
      cleared: false,
      innerTime: 0,
      settledTime: 0,
      startTime: 0,
      msg: '00:00:00'
    }
  },
  methods: {
    hourlabel: function (val) {
      this.hour = val
    },

    minlabel: function (val) {
      this.minute = val
    },

    seclabel: function (val) {
      this.second = val
    },

    DisplayNumber: function (hour, minute, second) {
      var showmsg = ''
      if (hour < 10) {
        showmsg += '0' + hour.toString()
      } else {
        showmsg += hour.toString()
      }
      showmsg += ':'
      if (minute < 10) {
        showmsg += '0' + minute.toString()
      } else {
        showmsg += minute.toString()
      }
      showmsg += ':'
      if (second < 10) {
        showmsg += '0' + second.toString()
      } else {
        showmsg += second.toString()
      }
      return showmsg
    },

    Update: function (data) {
      this.paused = data.paused
      if (this.paused) {
        this.pauseTime = new Date().getTime()
        if (this.up) {
          this.hint = '暂停正计时 ' + this.DisplayNumber(this.hour, this.minute, this.second)
        }
        if (this.down) {
          this.hint = '暂停倒计时 ' + this.DisplayNumber(this.hour, this.minute, this.second)
        }
      } else {
        this.resumeTime = new Date().getTime()
        this.startTime = this.startTime + this.resumeTime - this.pauseTime
        if (this.up) {
          this.hint = '正在正计时 ' + this.DisplayNumber(this.hour, this.minute, this.second)
        }
        if (this.down) {
          this.hint = '正在倒计时 ' + this.DisplayNumber(this.hour, this.minute, this.second)
        }
      }
    },

    Inc: function () {
      var hintmsg
      if ((isNaN(this.hour)) || (this.hour < 0)) {
        this.hour = 0
      }
      if (this.hour > 99) {
        this.hour = 99
      }
      if ((isNaN(this.minute)) || (this.minute < 0)) {
        this.minute = 0
      }
      if (this.minute > 59) {
        this.minute = 59
      }
      if ((isNaN(this.second)) || (this.second < 0)) {
        this.second = 0
      }
      if (this.second > 59) {
        this.second = 59
      }
      this.startTime = new Date().getTime()
      this.innerTime = 0
      this.settledTime = this.hour * 3600 * 10 + this.minute * 60 * 10 + this.second * 10
      this.begin = false
      this.end = false
      this.up = true
      this.down = false
      this.paused = false
      this.cleared = false
      hintmsg = this.DisplayNumber(this.hour, this.minute, this.second)
      this.hint = '正在正计时 ' + hintmsg
      setTimeout(this.IncCall, 100)
    },

    IncCall: function () {
      if (!this.paused) {
        this.innerTime++
      }
      var hour = Math.floor(this.innerTime / (3600 * 10))
      var minute = Math.floor(this.innerTime / (60 * 10)) % 60
      var second = Math.floor(this.innerTime / 10) % 60
      var offset = new Date().getTime() - (this.startTime + (this.innerTime - 1) * 100)
      var nextTime = 100 - offset
      if (this.innerTime >= this.settledTime) {
        this.cleared = false
        this.end = true
        this.msg = this.DisplayNumber(hour, minute, second)
        this.hint = '正计时 ' + this.msg + ' 已结束'
      } else if (!this.cleared) {
        this.msg = this.DisplayNumber(hour, minute, second)
        setTimeout(this.IncCall, nextTime)
      }
    },

    Dec: function () {
      var hintmsg
      if ((isNaN(this.hour)) || (this.hour < 0)) {
        this.hour = 0
      }
      if (this.hour > 99) {
        this.hour = 99
      }
      if ((isNaN(this.minute)) || (this.minute < 0)) {
        this.minute = 0
      }
      if (this.minute > 59) {
        this.minute = 59
      }
      if ((isNaN(this.second)) || (this.second < 0)) {
        this.second = 0
      }
      if (this.second > 59) {
        this.second = 59
      }
      this.startTime = new Date().getTime()
      this.innerTime = 0
      this.settledTime = this.hour * 3600 * 10 + this.minute * 60 * 10 + this.second * 10
      if (this.settledTime === 0) {
        this.begin = false
        this.end = true
        this.up = false
        this.down = true
        this.paused = false
        this.cleared = false
        hintmsg = this.DisplayNumber(0, 0, 0)
        this.hint = '倒计时' + hintmsg + '已结束'
      } else {
        this.begin = false
        this.end = false
        this.up = false
        this.down = true
        this.paused = false
        this.cleared = false
        hintmsg = this.DisplayNumber(this.hour, this.minute, this.second)
        this.hint = '正在倒计时 ' + hintmsg
        setTimeout(this.DecCall, 100)
      }
    },

    DecCall: function () {
      if (!this.paused) {
        this.innerTime++
      }
      var hour = Math.floor((this.settledTime - this.innerTime) / (3600 * 10))
      var minute = Math.floor((this.settledTime - this.innerTime) / (60 * 10)) % 60
      var second = Math.floor((this.settledTime - this.innerTime) / 10) % 60
      var offset = new Date().getTime() - (this.startTime + (this.innerTime - 1) * 100)
      var nextTime = 100 - offset
      if (this.innerTime >= this.settledTime) {
        this.cleared = false
        this.end = true
        this.msg = this.DisplayNumber(hour, minute, second)
        this.hint = '倒计时 ' + this.msg + ' 已结束'
      } else if (!this.cleared) {
        this.msg = this.DisplayNumber(hour, minute, second)
        setTimeout(this.DecCall, nextTime)
      }
    },

    Clear: function () {
      location.reload()
    },

    Restart: function () {
      if (this.up) {
        this.Inc()
      } else if (this.down) {
        this.Dec()
      }
    },

    keyenter: function () {
      if (this.begin) {
        this.Inc()
      }
    },

    keyspace: function () {
      if (!this.begin && !this.end) {
        this.StateTrans()
      }
    },

    StateTrans: function () {
      this.paused = ~this.paused
      if (this.paused) {
        this.pauseTime = new Date().getTime()
        if (this.up) {
          this.hint = '暂停正计时 ' + this.DisplayNumber(this.hour, this.minute, this.second)
        } else if (this.down) {
          this.hint = '暂停倒计时 ' + this.DisplayNumber(this.hour, this.minute, this.second)
        }
      } else {
        this.resumeTime = new Date().getTime()
        this.startTime = this.startTime + this.resumeTime - this.pauseTime
        if (this.up) {
          this.hint = '正在正计时 ' + this.DisplayNumber(this.hour, this.minute, this.second)
        } else if (this.down) {
          this.hint = '正在倒计时 ' + this.DisplayNumber(this.hour, this.minute, this.second)
        }
      }
    },

    keyevts (event) {
      const e = event || window.event
      if (!e) return
      const {key, keyCode} = e
      if (keyCode === 13) {
        this.keyenter()
      } else if (keyCode === 32) {
        this.keyspace()
      }
      return key
    }
  },
  mounted () {
    window.addEventListener('keyup', this.keyevts)
  }
}
</script>

<style>
*{
  margin: 0;
  padding: 0;
}
#app {
  margin: 0;
  padding: 0;
  width: 1220px;
  height: 510px;
  background-color: #F2F4F7;
  box-shadow: 0px 2px 4px 0px rgba(0,0,0,0.10);
}
#Rectangle1{
   position: fixed;
   background-color: #97a5bc;
   height: 70px;
   width: 1140px;
   top: 0;
   left: 40px;
}
#Rectangle2{
   position: fixed;
   background-color: #f2f4f7;
   height: 440px;
   width: 1140px;
   top: 70px;
   left: 40px;
   text-align: center;
}
#Header{
  width: 1220px;
  height: 70px;
  background-color: #97A5BC;
  box-shadow: 0px 2px 4px 0px rgba(0,0,0,0.10);
}
</style>
