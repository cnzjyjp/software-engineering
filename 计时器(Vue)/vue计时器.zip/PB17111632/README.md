## 如何使用计时器

**说明：因为是用webpack整合的，所以在根目录(index.html所在的目录)里还额外需要保留整合生成的`.babaelrc`, `.eslintrc.js`,`.eslintignore`三个文件，否则npm run dev会出错。**

以下指令均在windows cmd中执行，执行中途请勿关闭cmd窗口。

在cmd中通过npm安装vue.js（也可以通过其他方法）：

```
npm install vue
```

进入index.html所在的目录，依次执行以下两条指令：

```
npm install

npm run dev
```

如果`npm install`报错`Unexpected end of JSON input while parsing near...`，则在相同路径下先执行`npm cache clean --force`然后再执行上述两条指令。

显示DONE后，将cmd窗口中返回的信息中的网址复制，例如若返回信息为：

```
Your application is running here: http://localhost:8080
```

则复制http://localhost:8080，在任意浏览器访问网址即可到达计时器页面。