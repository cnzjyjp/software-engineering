<template>
    <div>
        <p>
            <router-link to="/home">返回主页</router-link>
        </p>
        <p>
            <router-link to="/login">Logout</router-link>
        </p>
    </div>
</template>

<script>
/*export default {
    
}*/
</script>