<template>
    <div>
    <el-select v-model="term" size:medium  placeholder="请选择" class="select_term" @change="changeTerm($event)">
    <el-option
      v-for="item in options"
      :key="item.value"
      :label="item.label"
      :value="item.value">
    </el-option>
  </el-select>
  <p>当前学期是{{$route.params.term}}</p>
        <p>
            <router-link :to="'/courses/'+$route.params.term+'/'+$route.params.course_id+'/qazone'">前往{{$route.params.course_id}}的答疑区</router-link>
        </p>
        <p>
            <router-link :to="'/courses/'">返回课程列表</router-link>
        </p>
          <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
         <el-tab-pane label="课程信息" name="first">{{course_info.name}}</el-tab-pane>
         <el-tab-pane label="课程公告" name="second">{{course_info.notice}}</el-tab-pane>
         </el-tabs>
        <p v-if="course_info==='None'">所选学期没有该课程信息</p>

    </div>

</template>

<script>
import axios from 'axios';
axios.defaults.withCredentials = true
import config from 'config';
export default {
    data () {
        return {
            activeName: 'first',
            options: [{
                value: '201',
                label: '2020春季学期'
                }, {
                value: '192',
                label: '2019秋季学期'
                }, {
                value: '191',
                label: '2019春季学期'
                }, {
                value: '182',
                label: '2018秋季学期'
                }, {
                value: '181',
                label: '2018春季学期'
                }],
                term: '',
                course_info:''
            }
    },
    created(){
            let temp='lesson_id='+this.$route.params.course_id+'&'+'term='+this.$route.params.term;
            axios.post(`${config.apiUrl}/lesson/info`, temp,{
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
            }).then(this.handleCourseInfo)
    },
    methods: {
        changeTerm(e){
          this.$router.push({name:'courseinfo',params:{term:this.term,course_id:this.$route.params.course_id}});
        },
        handleClick(tab, event) {

      },
        handleCourseInfo(response)
        {
            console.log(response);
            console.log(response.data.lesson_info);
            this.course_info=response.data.lesson_info;

        },
        getinfo(){
            let temp='lesson_id='+this.$route.params.course_id+'&'+'term='+this.$route.params.term;
            axios.post(`${config.apiUrl}/lesson/info`, temp,{
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
            }).then(this.handleCourseInfo)
        }
    },
    watch:{
        term:'getinfo'
    }
}
</script>
<style>
 .select_term{
    width:400px;
    text-align:center;
  }  
</style>