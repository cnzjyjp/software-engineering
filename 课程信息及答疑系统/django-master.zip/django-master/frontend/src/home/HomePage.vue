<template>
    <div>
        <p>
            <router-link to="/userinfo">个人信息</router-link>
        </p>
        <p>
            <router-link to="/courses">课程信息</router-link>
        </p>
        <p>
            <router-link to="/login">Logout</router-link>
        </p>
    </div>
</template>

<script>
// import { mapState, mapActions } from 'vuex'

// export default {
//     computed: {
//         ...mapState({
//             account: state => state.account,
//             users: state => state.users.all
//         })
//     },
//     created () {
//         this.getAllUsers();
//     },
//     methods: {
//         ...mapActions('users', {
//             getAllUsers: 'getAll',
//             deleteUser: 'delete'
//         })
//     }
// };
</script>