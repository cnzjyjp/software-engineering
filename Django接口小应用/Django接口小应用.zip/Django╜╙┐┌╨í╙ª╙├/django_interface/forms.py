from django import forms

from .models import DateQuery

class DateForm(forms.ModelForm):
    class Meta:
        model = DateQuery
        fields = ['Date']
        labels = {'Date': ''}