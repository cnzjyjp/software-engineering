<template>
    <div>
        <h2>Course lookup </h2>
        <form @submit.prevent="handleSubmit">
            <div class="form-group">
                <label for="lesson_id">Lesson id</label>
                <input type="text" v-model="lesson_id" name="lesson_id" class="form-control" :class="{ 'is-invalid': submitted }" />
                <div v-show="submitted" class="invalid-feedback">lesson_id is required</div>
            </div>
            <div class="form-group">
                <label htmlFor="question_id">Question id</label>
                <input type="text" v-model="question_id" name="question_id" class="form-control" :class="{ 'is-invalid': submitted}" />
                <div v-show="submitted" class="invalid-feedback">question_id is required</div>
            </div>
            <div class="form-group">
                <button class="btn btn-primary">Submit</button>
                <img v-show="status.loggingIn" src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                <router-link to="/" class="btn btn-link">home</router-link>
            </div>
            <h3>Question</h3>
            <p>{{question_messeges}}</p>
            <h3>lesson</h3>
            <p>{{lesson_messages}}</p>
        </form>
    </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import config from 'config';
import axios from 'axios';
axios.defaults.withCredentials = true
export default {
    data () {
        return {
            submitted: false,
            lesson_id:'',
            question_id:'',
            question_messeges:'',
            lesson_messages:''
        }
    },
    computed: {
        ...mapState('account', ['status'])
    },
    created () {
        // reset login status
        // this.logout();
    },
    methods: {
        ...mapActions('account', ['login', 'logout']),
        handleSubmit (e) {
            this.submitted = true;
            console.log(document.cookie);
            let temp='lesson_id='+this.lesson_id+'&'+'questionid='+this.question_id;
            axios.post(`${config.apiUrl}/webapp/course`, temp,
                {
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },

                })
                .then(this.handleLookup)
        },
        handleLookup(response)
        {
            console.log(response);
            console.log(response.data);
            // this.lesson_messages=response.data.le
            this.question_messeges=response.data['question_info'];
            this.lesson_messages=response.data['lesson_info'];
        }
    }
};
</script>