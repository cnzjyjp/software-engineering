import Vue from 'vue';
import Router from 'vue-router';

import HomePage from '../home/HomePage'
import LoginPage from '../login/LoginPage'
import RegisterPage from '../register/RegisterPage'
import CourseInfo from '../course/CourseInfo'
import CourseList from '../course/CourseList'
import AddQuestion from '../course/AddQuestion'
import QAZone from '../course/QAZone'
// import QAZoneInfo from '../course/QAZoneInfo'
import UserInfo from '../userinfo/UserInfo'

Vue.use(Router);

export const router = new Router({
  mode: 'history',
  routes: [
    { path: '/home', name:'home', component: HomePage },
    { path: '/login', name:'login', component: LoginPage },
    { path: '/register', name:'register', component: RegisterPage },
    { path: '/userinfo',name:'userinfo', component:UserInfo},
    { path: '/courses',name:'courselist', component:CourseList},
    { path: '/courses/:term/:course_id',name:'courseinfo', component:CourseInfo},  
    { path: '/courses/:term/:course_id/qazone',name:'qazone', component:QAZone, 
    children: [
      {
        path: 'addquestion',
        component: AddQuestion
      }
    ]}, 
    // { path: '/courses/:term/:course_id/qazone',name:'qazone', component:QAZone}, 
    // { path: '/courses/:term/:course_id/qazone/addquestion',name:'addquestion', component:AddQuestion},

    // otherwise redirect to home
    { path: '*', redirect: '/home' }
  ]
});

router.beforeEach((to, from, next) => {
  // redirect to login page if not logged in and trying to access a restricted page
  const publicPages = ['/login', '/register'];
  const authRequired = !publicPages.includes(to.path);
  const loggedIn = localStorage.getItem('user');
  console.log(loggedIn);
  console.log(authRequired);
  if (authRequired && !loggedIn) {
    return next('/login');
  }

  next();
})


